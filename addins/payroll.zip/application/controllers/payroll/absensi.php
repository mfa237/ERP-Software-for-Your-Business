<?php if(!defined('BASEPATH')) exit('No direct script access allowd');

class Absensi extends CI_Controller {
	function __construct()
	{
		parent::__construct();
 		$this->load->helper(array('url','form','mylib_helper'));
		$this->load->library('template');
		if(!$this->access->is_login())redirect(base_url());
	 	$this->load->model("payroll/time_card_detail_model");
		
	}
	function index()
	{
		$data['title']='DATA ABSENSI';
		$data['tanggal']= date("Y-m-d H:i:s");	
		$this->load->model('periode_model');
		$data['periode']=date("Y-m");	///$this->periode_model->current_periode();
		$data['periode_list']=$this->periode_model->dropdown();
		$data['nip']='';
		$data['nama']='Not Found !';
		$data['dept']='';
		$data['divisi']='';		
        $this->template->display('payroll/absensi_data',$data,'');
	}
	function data(){
		$sql="select e.nip,e.nama,a.time_in,a.time_out,a.id 
		from employee e left join time_card_detail a 
		on a.nip=e.nip and year(tanggal)=".date("Y")." and month(tanggal)=".date('m')." and day(tanggal)=".date('d');
		echo datasource($sql);
	}
	function data_nip($nip,$periode){
		 $nip=urldecode($nip);
		 $periode=urldecode($periode);
		
		$this->load->model('periode_model');
		$periode=$this->periode_model->get_by_id($periode)->row();
		$sql="select a.tanggal,e.nip,e.nama,a.time_in,a.time_out,a.id,a.ot_in,a.ot_out 
		from employee e left join time_card_detail a 
		on a.nip=e.nip where a.nip='".$nip."' and a.tanggal between '"
			.$periode->startdate."' and '".$periode->enddate."'";
		echo datasource($sql);
	}	
	
	function delete($id){
		if($ok=$this->db->where("id",$id)->delete("time_card_detail")){
			echo json_encode(array("success"=>true,"msg"=>"Data sudah dihapus."));
		} else {
			echo json_encode(array("success"=>false,"msg"=>mysql_error()));
		}		
	}
 	function save($vdata=null){
		if($vdata){
			$data=$vdata;
		} else {
			if($this->input->post()){
				$data=$this->input->post();
			} else {
				$data=$this->input->get();
			}
		}
		$id="";
		if(isset($data['id']))$id=$data['id'];
		$data['salary_no']=0;
		$nip=$data['nip'];
		$tanggal=$data['tanggal'];
		$jenis="";
		if(isset($data['jenis'])){
				$jenis=$data['jenis'];
				unset($data['jenis']);
		}
		$sql="select time_in,time_out,id from time_card_detail 
		where nip='$nip' ";
		if($id==""){
			$sql=$sql." and year(tanggal)=".date("Y",strtotime($tanggal))
			." and month(tanggal)=".date('m',strtotime($tanggal))
			." and day(tanggal)=".date('d',strtotime($tanggal));
		} else {
			$sql=$sql." and id=".$id;
		}
		$query=$this->db->query($sql);
		if($query->num_rows()>0) {
			$id=$data['id'];
			if($id==""){
				$row=$query->row();
				$id=$row->id;
			}
			//unset($data['tanggal']);
			//unset($data['time_in']);
			unset($data['id']);
			$ok=$this->time_card_detail_model->update($id,$data);				
			
		} else {
			$ok=$this->time_card_detail_model->save($data);			
		}
		if($ok){echo json_encode(array("success"=>true));} 
		else {echo json_encode(array("msg"=>"Error ".mysql_error()));}
	}
	function detail($nip=''){
		 $nip=urldecode($nip);
		$data['nip']=$nip;
		$this->load->model('periode_model');
		$data['periode']=date("Y-m");	///$this->periode_model->current_periode();
		$data['periode_list']=$this->periode_model->dropdown();
		$this->load->model('employee_model');

		$data['nama']='Not Found !';
		$data['dept']='';
		$data['divisi']='';

		$q=$this->employee_model->get_by_id($nip);
		if($q){
			if($emp=$q->row()){
				$data['nama']=$emp->nama;
				$data['dept']=$emp->dept;
				$data['divisi']=$emp->divisi;		
			}
		}
		$this->template->display('payroll/absensi_data',$data);
	}
	function import_from_user_login($date_from,$date_to){
		$s="select * from syslog where jenis in ('LOGIN','LOGOUT') 
			and tgljam between '".date("Y-m-d",strtotime($date_from))."' 
				and '".date("Y-m-d",strtotime($date_to))." 23:59:59' 
				and userid is not null
				order by userid,tgljam";
		if($query=$this->db->query($s)) { 
			foreach($query->result() as $row){
				$nip="";
				$data=null;
				if($quser=$this->db->query("select nip from `user` 
					where user_id='".$row->userid."'")){
					if($ruser=$quser->row()){
						$nip=$ruser->nip;
						if($nip==null)$nip="";
					}
				}
				if($nip==null)$nip="";
				if($nip=="")$nip=$row->userid;
				if($nip<>""){
					$data['time_in']=date("H:i",strtotime($row->tgljam));
					$data['time_out']=date("H:i",strtotime($row->tgljam));
					$data['nip']=$nip;
					$data['tanggal']=date("Y-m-d",strtotime($row->tgljam));
					$data['jenis']=$row->jenis;
					$this->save($data);
				}
			}
		}
	}
	function convert_login_absen(){
		if($this->input->post('date_from')){
			$data=$this->input->post();
			$d1=date("Y-m-d H:i:s",strtotime($data['date_from']));
			$d2=date("Y-m-d H:i:s",strtotime($data['date_to'])); 
			//hapus dulu data absensi lama
			$s="delete from time_card_detail where tanggal between '$d1' and '$d2' ";
			//$this->db->query($s);

			$this->import_from_user_login($d1,$d2);
				$data['message']="Data absensi sudah dibuatkan berdasarkan periode tanggal tersebut.";
				$sql="select nip,tanggal,time_in,time_out  
					from time_card_detail where tanggal between '$d1' and '$d2' 
					order by nip,tanggal,time_in";
				// save session untuk export ke excel
				$this->session->set_userdata("date_from",$d1);
				$this->session->set_userdata("date_to",$d2);
				
				if($query=$this->db->query($sql)){
					$data['absen_list']=$query;
				}
		} else {
			$data['date_from']=date("m/d/Y");
			$data['date_to']=date("m/d/Y");		
		}
		$this->template->display("payroll/absensi_import_login",$data);
	}
	function export_xls(){
		$d1=$this->session->userdata("date_from");
		$d2=$this->session->userdata("date_to");
		$sql="select nip,tanggal,time_in,time_out  
					from time_card_detail where tanggal between '$d1' and '$d2' 
					order by nip,tanggal,time_in";
		header("Content-type: application/vnd-ms-excel");
		header("Content-Disposition: attachment; filename=hasil-export.xls");
		echo html_table($sql,false);
	}
	 
}


     <div class="col-sm-6 col-md-4"><h2>Reports</h2>
 		<div class="thumbnail"> 
			<li><?=anchor('payroll/rpt/emp_list','Daftar Karyawan')?></li>
			<li><?=anchor('payroll/rpt/slip_list','Daftar Slip Gaji')?></li>
			<li><?=anchor('payroll/rpt/slip_print','Cetak Slip Gaji Massal')?></li>
			<li><?=anchor('payroll/rpt/slip_bank','Rangkuman Gaji per Bank')?></li>
			<li><?=anchor('payroll/rpt/absensi','Daftar Absensi')?></li>
			<li><?=anchor('payroll/rpt/overtime','Daftar Overtime')?></li>
 		</div>
 	</div>	

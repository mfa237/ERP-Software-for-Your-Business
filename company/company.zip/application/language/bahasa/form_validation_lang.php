<?
$lang['save']='Simpan';
$lang['add']='Tambah';
$lang['print']='Cetak';
$lang['search']='Cari';
$lang['posting']='Posting';
$lang['import']='Import';
$lang['export']='Export';
$lang['help']='Help';
$lang['picture']='Foto';
$lang['options']='Options';

?>
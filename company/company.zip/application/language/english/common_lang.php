<?
$lang['save']='Save';
$lang['add']='Add';
$lang['print']='Print';
$lang['search']='Search';
$lang['posting']='Posting';
$lang['import']='Import';
$lang['export']='Export';
$lang['help']='Help';
$lang['picture']='Foto';
$lang['options']='Options';
$lang['refresh']='Refresh';

?>
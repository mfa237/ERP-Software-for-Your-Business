<?php 
//if (!defined('BASEPATH')) exit('No direct script access allowed');

class search_criteria{
	public $caption='';
	public $field_id='';
	public $field_class='';
	public $field_value='';
	public $field_style='';

	 function __construct()
	 {
	 }
}

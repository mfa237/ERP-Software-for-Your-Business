<?php
class Purchase_order_lineitems_model extends CI_Model {

private $primary_key='line_number';
private $table_name='purchase_order_lineitems';

function __construct(){
	parent::__construct();
}
  
function count_all(){
	return $this->db->count_all($this->table_name);
}
function get_by_id($id){
	$this->db->where($this->primary_key,$id);
	return $this->db->get($this->table_name);
}
function get_by_nomor($nomor) {
	$this->db->where('purchase_order_number',$nomor);
	return $this->db->get($this->table_name);
}
function default_values($data){
	if(!isset($data['warehouse_code']))$data['warehouse_code']='GUDANG';
	if($data['warehouse_code']=='')$data['warehouse_code']='GUDANG';
	if(!isset($data['currency_code']))$data['currency_code']='IDR';
	if($data['currency_code']=='')$data['currency_code']='IDR';
	if(!isset($data['currency_rate']))$data['currency_rate']=1;
	if($data['currency_rate']<=0)$data['currency_rate']=1;
	if(!isset($data['mu_qty']))$data['mu_qty']=$data['quantity'];
	if($data['mu_qty']<=0)$data['mu_qty']=$data['quantity'];
	if(!isset($data['mu_harga']))$data['mu_harga']=$data['price'];
	if($data['mu_harga']<=0)$data['mu_harga']=$data['price'];
	if(!isset($data['multi_unit']))$data['multi_unit']=$data['unit'];
	if($data['multi_unit']=='')$data['multi_unit']=$data['unit'];
	
	return $data;
}
function save($data){
	$data=$this->default_values($data);
	if($unit=exist_unit($data['unit'])){
		$data['mu_qty']=$data['quantity']*$unit['unit_value'];
		$data['mu_harga']=item_purchase_price($data['item_number']);
		$data['multi_unit']=$unit['from_unit'];		
	} else {
		$data['mu_qty']=$data['quantity'];
		$data['mu_harga']=$data['price'];
		$data['multi_unit']=$data['unit'];
	}	
	$this->db->insert($this->table_name,$data);
	
	return $this->db->insert_id();
}
function update($id,$data){
	$data=$this->default_values($data);
	if($unit=exist_unit($data['unit'])){
		$data['mu_qty']=$data['quantity']*$unit['unit_value'];
		$data['mu_harga']=item_purchase_price($data['item_number']);
		$data['multi_unit']=$unit['from_unit'];		
	} else {
		$data['mu_qty']=$data['quantity'];
		$data['mu_harga']=$data['price'];
		$data['multi_unit']=$data['unit'];
	}
	$this->db->where($this->primary_key,$id);
	return $this->db->update($this->table_name,$data);
}
function delete($id){
	$this->db->where($this->primary_key,$id);
	return $this->db->delete($this->table_name);
}
function lineitems($po_number){
	$this->db->where('purchase_order_number',$po_number);
	return $this->db->get($this->table_name);
}
function sum_total_price($nomor)
{
	$rst=$this->db->query("select sum(total_price) as sum_total_price 
		from purchase_order_lineitems 
        where purchase_order_number='".$nomor."'");
    if($rst->num_rows()){    
        return $rst->row()->sum_total_price;
	} else {
		return 0;
	}
}
function browse($nomor)
{
	$sql="select p.item_number,i.description,p.quantity 
	,p.unit,p.price,p.discount,p.total_price,coa.account,coa.account_description,p.line_number
	from purchase_order_lineitems p
	left join inventory i on i.item_number=p.item_number
	left join chart_of_accounts coa on coa.id=p.inventory_account
	where purchase_order_number='$nomor'";
	$this->load->helper('browse_helper');
	return browse_simple($sql,"Data Barang / Jasa",500,300,"dgItem");
}
function update_qty_received($line,$qty){
	$sql="update purchase_order_lineitems set qty_recvd=IFNULL(qty_recvd,0)+$qty where line_number=$line";
	$this->db->query($sql);
	$sql="select quantity-IFNULL(qty_recvd,0) from purchase_order_lineitems 
	where line_number=$line";
	$sql="update purchase_order_lineitems set received=true 
	where line_number=$line and ifnull(qty_recvd,0)>=quantity";
	$this->db->query($sql);
}
function create_po_by_request($supplier,$purchase_order_number) {
	if(strtolower($supplier)=='unknown')$supplier='';
	$sql="select p.purchase_order_number,p.po_date,p.due_date,p.terms,p.project_code,p.branch_code,p.dept_code,p.ordered_by,p.doc_status,
	i.item_number,i.description,i.quantity,i.unit,t.supplier_number,i.line_number,t.cost,t.cost_from_mfg
	from purchase_order  p left join purchase_order_lineitems i on i.purchase_order_number=p.purchase_order_number
	left join inventory t on t.item_number=i.item_number 
	where ifnull(selected,0)=0 and  p.doc_status='open' and p.potype='Q' and ifnull(t.supplier_number,'')='".$supplier."' 
	order by i.item_number";								
	if($qline=$this->db->query($sql)){
		foreach($qline->result() as $row_items){
			$dline=data_table('purchase_order_lineitems',null);
			$dline['purchase_order_number']=$purchase_order_number;
			$dline['item_number']=$row_items->item_number;
			$dline['description']=$row_items->description;
			$dline['quantity']=$row_items->quantity;
			$dline['unit']=$row_items->unit;
			$dline['price']=$row_items->cost_from_mfg;
			if(!$dline['price'])$dline['price']=$row_items->cost;
			if(!$dline['price'])$dline['price']=0;
			$dline['total_price']=$dline['quantity']*$dline['price'];
			$dline['from_line_doc']=$row_items->purchase_order_number;
			$dline['from_line_type']='PO Request';
			$dline['from_line_number']=$row_items->line_number;
			if($this->save($dline)){
				$this->db->query("update purchase_order_lineitems set selected=1 where line_number=".$row_items->line_number);
			}
		}
	}
	
}

}

<form  id="frmSales" method='post' >
	<table>
		<tr>
			<td colspan="2"><h2>SETTING LAIN-LAIN</h2></td>
		</tr>
		<!--
		<tr>
			<td>Boleh ubah discount ketika transaksi</td><td><?
			echo form_input('accounts_payable',$a,'id="accounts_payable" style="width:250px"');
			?></td>
		</tr>
		-->

	</table>
	
	<input type='submit' name='cmdSave'>
</form>


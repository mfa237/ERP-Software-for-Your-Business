<form  id="frmPurchase" method='post' >
	<table>
		<tr>
			<td colspan="2"><h2>SETTING PEMBELIAN</h2></td>
		</tr>

	</table>
	
	<input type='submit' name='cmdSave'>
</form>


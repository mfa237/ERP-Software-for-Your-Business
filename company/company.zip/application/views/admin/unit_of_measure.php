<?php 
echo $unit_of_measure;
?>
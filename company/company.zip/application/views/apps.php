<?
$title="DAFTAR APLIKASI DAN ADDONS";
$help="apps";
$form_controller="apps";
$field_key="id";
include_once "simple_form.php"
?>

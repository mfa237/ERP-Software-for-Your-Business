<?php 
if(isset($message)) echo $message;
if(isset($content)) echo $content;
?>
<?
$title="DAFTAR KOTA";
$help="city";
$form_controller="city";
$field_key="city_id";
include_once "simple_form.php"
?>

<div  style="height:auto;;padding:10px">
	<div class="welcome_line welcome_t"></div>

	<div class="panel panel-primary " >
		<div class="panel-heading">
				<h3 class="panel-title"  style="padding:10px;color:white">DONASI DAN KEGIATAN</h3>
		</div>
		<div class="panel-body"   style="padding:10px;">
			<p>
				Jika ANDA ingin menjadi Donatur yang sangat kami hargai, 
				anda bisa mengklik tautan di bawah ini. 
				Donasi anda akan kami gunakan untuk pengembangan MAXON dan akan kami salurkan 
				untuk kegiatan pendidikan anak-anak usia dini (PAUD)
				dan taman kanak-kanak (TK), 
				sebagai penerus kehidupan berbangsa dan bernegara yang lebih baik.
				<div class='col-sm-5 thumbnail '>
					<img src="<?=base_url()?>images/bca.jpg" width="130px" height="130px" align="left">
				 <strong>BANK BCA</strong> 
					 <br>ANDRI ANDIANA 
					 <br>2400 0920 98
					 <br>Cabang Jakarta
				</div>
				<div class='col-sm-5 thumbnail '>
				<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
					<input type="hidden" name="cmd" value="_s-xclick">
					<input type="hidden" name="hosted_button_id" value="3B2BALTFG7KWQ">
					<input type="image" src="<?=base_url()?>images/paypal.jpg" style="width:165px!important;"  
					 width="130px" height="100px"  border="0" name="submit" alt="PayPal - The safer, easier way to pay online!" align="left">
					<img alt="Paypal" border="0" src="" width="10" height="10">
					<strong>PAYPAL</strong> 
					<br>
					
				</form>
				</div>
			</p>
			<div class="clearfix"></div>
			<p>
				<img src="<?=base_url()?>images/donate/paud1.jpg"  class="col-md-3 img-responsive" style="margin:10px">
				<img src="<?=base_url()?>images/donate/paud2.jpg"  class="col-md-3 img-responsive" style="margin:10px">
				<img src="<?=base_url()?>images/donate/paud4.jpg"  class="col-md-3 img-responsive" style="margin:10px">
			</p>	
		
       </div>
	</div>
</div>

<div class='clear'></div>
<div class='col-md-12 navbar-maxon box-footer bg-head-foot' style='border-top:1px solid lightgray;margin-top:10px;padding:10px'>
<img src='<?=base_url()?>images/logo_maxon.png' style='float:left;margin:5px'>
<p>Copyright &copy;2000-2015 Talagasoft Indonesia 
- Developed & Design by www.talagasoft.com</p>
<li><a href='http://www.facebook.com/maxon51'  target='_new'>Facebook MaxOn ERP</a></li>
<li><a href='http://www.twitter.com/talagasoft'  target='_new'>Twitter MaxOn ERP</a></li>
<li><a href='http://forum.maxonerp.com/' target='_new'>Forum MaxOn ERP</a></li>
<li><a href='http://www.talagasoft.com/' >Talagasoft Indonesia</a></li>
</div>

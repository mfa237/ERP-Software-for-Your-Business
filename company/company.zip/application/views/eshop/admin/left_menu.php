<div class="panel panel-default">
  <div class="panel-body">
	<h4>Admin</h4>
	<ul class="list-group">
	  <li class="list-group-item"><a href='<?=base_url()?>index.php/eshop_admin/dashboard'>DASHBOARD</a></li>
	  <li class="list-group-item"><a href='<?=base_url()?>index.php/eshop_admin/items'>KATALOG</a></li>
	  <li class="list-group-item"><a href='<?=base_url()?>index.php/eshop_admin/categories'>KATEGORI</a></li>
	  <li class="list-group-item"><a href='<?=base_url()?>index.php/eshop_admin/customers'>PELANGGAN</a></li>
	  <li class="list-group-item"><a href='<?=base_url()?>index.php/eshop_admin/orders'>TAGIHAN</a></li>
	  <!--
	  <li class="list-group-item">VOUCHER</li>
	  <li class="list-group-item">MODUL</li>
	  <li class="list-group-item">PENGIRIMAN</li>
	  <li class="list-group-item">LOKALISASI</li>
	  -->
	  <li class="list-group-item">PREFERENSI</li>
	  <li class="list-group-item">&nbsp&nbsp - &nbsp <a href='<?=base_url()?>index.php/eshop_admin/preference/store'>Informasi Toko</a></li>
	  <li class="list-group-item">&nbsp&nbsp - &nbsp <a href='<?=base_url()?>index.php/eshop_admin/slidder'>Slider Images</a></li>
	  <li class="list-group-item">&nbsp&nbsp - &nbsp <a href='<?=base_url()?>index.php/eshop_admin/articles'>Articles</a></li>
	  <!--
	  <li class="list-group-item">&nbsp&nbsp - &nbsp <a href='<?=base_url()?>index.php/eshop_admin/media'>Media</a></li>
	  <li class="list-group-item">&nbsp&nbsp - &nbsp <a href='<?=base_url()?>index.php/eshop_admin/themes'>Themes</a></li>
	  -->
	  <li class="list-group-item">SETTING</li>
	  <li class="list-group-item">&nbsp&nbsp - &nbsp <a href='<?=base_url()?>index.php/eshop_admin/banks'>Rekening Bank</a></li>
	  <!--
	  <li class="list-group-item">ADMINISTRASI</li>
	  <li class="list-group-item">STATISTIK</li>
	  -->
	</ul>
  </div>
</div>

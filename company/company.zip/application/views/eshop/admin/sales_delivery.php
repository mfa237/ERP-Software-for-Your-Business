 
	<h3>Delivery Information</h3>
	<table class='table'>
	<tr><td>Tanggal </td><td><?=$so->ship_date?></td></tr>
	<tr><td>Jasa Pengiriman </td><td><?=$so->shipped_via?></td></tr>
	<tr><td>Perkiraan Sampai </td><td><?=$so->ship_day?></td></tr>
	<tr><td>Berat</td><td><?=$so->ship_weight?></td></tr>
	<tr><td>Nomor Resi Pengiriman</td><td><?=$so->ship_no?></td></tr>
	</table>
 


<div class='well'>
<h3>Themas</h3>
<p>Themas adalah tampilan layar warna dan posisi pada halaman toko online anda, thema tersedia 
sebagai tema standard atau berbayar yang bisa bisa anda download di market maxon.</p>
</div> 